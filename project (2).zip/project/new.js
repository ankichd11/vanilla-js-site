function w3_open() {
    document.getElementById("mySidebar").style.width = "25%";
    document.getElementById("mySidebar").style.display = "block";
}

function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
}

function cng1() {
    document.getElementById('changep').style.backgroundImage = 'linear-gradient(to bottom right, rgba(255,0,0,0.5),white, rgba(255,255,0,0.5))';
}

function cng2() {
    document.getElementById('changep').style.backgroundImage = 'linear-gradient(to bottom right, rgba(139,0,139,0.5),white, rgba(255,105,180,0.5))';
}

function cng3() {
    document.getElementById('changep').style.backgroundImage = 'linear-gradient(to bottom right, rgba(0,128,0,0.5),white, rgba(255,255,0,0.5))';
}

function cng4() {
    document.getElementById('changep').style.backgroundImage = 'linear-gradient(to bottom right, rgba(76,0,255,0.5),white, rgba(48,214,236,0.5))';
}

function cng5() {
    document.getElementById('changep').style.backgroundImage = 'linear-gradient(to bottom right, rgba(8,9,78,0.5),white, rgba(13,131,58,0.5))';
}

function cng6() {
    document.getElementById('changep').style.backgroundImage = 'linear-gradient(to bottom right, rgba(46,173,238,0.5),white, rgba(116,125,126,0.5))';
}

function wall01(){
    document.getElementById('wall').style.background="url('./photos/wall1.jpeg')";
    document.getElementById('wall').style.backgroundSize="cover";
    document.getElementById('wall').style.backgroundRepeat="no-repeat";
}

function wall02(){
    document.getElementById('wall').style.background="url('./photos/wall2.jpg')";
    document.getElementById('wall').style.backgroundSize="cover";
    document.getElementById('wall').style.backgroundRepeat="no-repeat";
}

function wall03(){
    document.getElementById('wall').style.background="url('./photos/wall3.jpg')";
    document.getElementById('wall').style.backgroundSize="cover";
    document.getElementById('wall').style.backgroundRepeat="no-repeat";
}

function wall04(){
    document.getElementById('wall').style.background="url('./photos/wall4.jpg')";
    document.getElementById('wall').style.backgroundSize="cover";
    document.getElementById('wall').style.backgroundRepeat="no-repeat";
}

function wall05(){
    document.getElementById('wall').style.background="url('./photos/wall5.jpg')";
    document.getElementById('wall').style.backgroundSize="cover";
    document.getElementById('wall').style.backgroundRepeat="no-repeat";
}

function wall06(){
    document.getElementById('wall').style.background="url('./photos/wall6.jpg')";
    document.getElementById('wall').style.backgroundSize="cover";
    document.getElementById('wall').style.backgroundRepeat="no-repeat";
}

